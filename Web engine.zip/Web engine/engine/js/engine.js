var currentPage = ''

const queryString = window.location.search;

const urlParams = new URLSearchParams(queryString);

current = "en-live-page"


var pids = urlParams.get('pid')

var pages = []

var data = null,
  pageData = null,
  pageElements = {}

var celem_list = []

elements = {}




var images = {}

var img_input = document.createElement('input');
img_input.type = 'file';
img_input.oninput = import_img;

function init_upload_img() {


  img_input.click();


}


function import_img() {
  var img = img_input.files[0]
  if (images[img.name] == null) {
    var durl = window.URL.createObjectURL(img)
    images[img.name] = durl
    console.log(images)
    load_images()
  }
}

function load_images() {
  var img_html = ''
  for (const [k, v] of Object.entries(images)) {
    img_html += `        
    <div class="en-media-box">

          <img src="` + v + `">
          <h3>` + k + `</h3>
          <button imgurl='` + v + `' class='en-media-bt-imp'>import</button>
          
        </div>`
  }
  document.getElementsByClassName('en-media-s')[0].innerHTML = img_html
}

function toggle_en_media(v = false) {
  let div = document.getElementById('en-media-window')

  if (div.style.display == 'none') {
    div.style.display = 'flex'
    load_images()
    let d = document.getElementsByClassName('en-media-bt-imp')
    if (v) {

      for (const [k, v] of Object.entries(d)) {
        v.style.display = 'block'
        v.onclick = () => {
          
          change_switch_property( "srcMEDIA",current, "srcMEDIA", Object.values(images)[k])
          toggle_en_media()
        }
      }
    }
    else {
      for (const [k, v] of Object.entries(d)) {
        v.style.display = 'none'
      }
    }
  } else {
    div.style.display = 'none'
  }
}


if (location.pathname.includes("offline")) {

  pids = prompt("Enter site name:")

  t = `while(pids == null || pids == ''){
    pids = prompt("Enter site name:")
  }`
  setup_offline()
  let did = current
  if (current != 'en-live-page') {
    did = current.split("-")[0]
  }
  document.getElementById('en-tab-prop-sel').innerHTML = 'Editing : ' + did
}


function setup_offline() {
  pages = []
  pages.push("home")
  currentPage = "home"
  data = {}
  data[pids] = { "pages": { "home": { "elements": {} } } }
  console.log(data)
  pageData = data[pids].pages[currentPage]
  if (data[pids].pages[currentPage].elements != null && Object.keys(data[pids].pages[currentPage].elements).length != 0) {
    elements = data[pids].pages[currentPage].elements
    pageElements = createDict(pageData.elements.key, pageData.elements.value)
    pageClasses = createDict(pageData.classes.key, pageData.classes.value)
    pageAnim = createDict(pageData.animations.key, pageData.animations.value)
    load_page_data()
  }
  load_pages()
  document.getElementById("en-loader").classList.toggle("hide")
}


function load_pages() {

  var html = ''
  for (const [i, v] of Object.entries(pages)) {
    html += `<option value="` + v + `">` + v + `</option>`
  }
  document.getElementById("en-pages-option").innerHTML = html
}


function download_page() {
  var elem_dic = {}

  var elem_key = []

  var elem_value = []
  for (const [k, v] of Object.entries(elements)) {
    elem_value.push(JSON.parse(JSON.stringify(v)))
    elem_key.push(k)
  }
  elem_dic.key = elem_key
  elem_dic.value = elem_value



  var class_dic = {}
  var class_key = []
  var class_value = []
  for (const [k, v] of Object.entries(classes)) {
    class_value.push(JSON.parse(JSON.stringify(v)))
    class_key.push(k)
  }
  class_dic.key = class_key
  class_dic.value = class_value


  var anim_dic = {}
  var anim_key = []
  var anim_value = []
  for (const [k, v] of Object.entries(animations)) {
    anim_value.push(JSON.parse(JSON.stringify(v)))
    anim_key.push(k)
  }
  anim_dic.key = anim_key
  anim_dic.value = anim_value
  data[pids].pages[currentPage].elements = elem_dic
  data[pids].pages[currentPage].classes = class_dic
  data[pids].pages[currentPage].animations = anim_dic


  pageData = data[pids].pages[currentPage]
  console.log(data)
  for (const [x, y] of Object.entries(pages)) {


    currentPage = y

    pageData = data[pids].pages[currentPage]
    if (data[pids].pages[currentPage].elements != null && Object.keys(data[pids].pages[currentPage].elements).length != 0) {
      elements = {}
      pageElements = createDict(pageData.elements.key, pageData.elements.value)
      pageClasses = createDict(pageData.classes.key, pageData.classes.value)
      pageAnim = createDict(pageData.animations.key, pageData.animations.value)
      load_page_data()
      var html = generate_html(currentPage)
      var a = document.createElement("a");
      a.href = window.URL.createObjectURL(new Blob([html], { type: "text/plain" }));
      a.download = currentPage + ".html";
      a.click();
    }
  }

}

function change_page(v) {
  var elem_dic = {}
  var elem_key = []
  var elem_value = []
  for (const [k, v] of Object.entries(elements)) {
    elem_value.push(JSON.parse(JSON.stringify(v)))
    elem_key.push(k)
  }
  elem_dic.key = elem_key
  elem_dic.value = elem_value



  var class_dic = {}
  var class_key = []
  var class_value = []
  for (const [k, v] of Object.entries(classes)) {
    class_value.push(JSON.parse(JSON.stringify(v)))
    class_key.push(k)
  }
  class_dic.key = class_key
  class_dic.value = class_value


  var anim_dic = {}
  var anim_key = []
  var anim_value = []
  for (const [k, v] of Object.entries(animations)) {
    anim_value.push(JSON.parse(JSON.stringify(v)))
    anim_key.push(k)
  }
  anim_dic.key = anim_key
  anim_dic.value = anim_value
  data[pids].pages[currentPage].elements = elem_dic
  data[pids].pages[currentPage].classes = class_dic
  data[pids].pages[currentPage].animations = anim_dic
  currentPage = v

  pageData = data[pids].pages[currentPage]

  if (data[pids].pages[currentPage].elements != null && Object.keys(data[pids].pages[currentPage].elements).length != 0) {
    elements = data[pids].pages[currentPage].elements
    pageElements = createDict(pageData.elements.key, pageData.elements.value)
    pageClasses = createDict(pageData.classes.key, pageData.classes.value)
    pageAnim = createDict(pageData.animations.key, pageData.animations.value)
    load_page_data()

  } else {
    let k = Object.keys(elements)[0],
      v = Object.values(elements)[0]
    elements = {}
    elements[k] = v
    document.getElementById("live-page").innerHTML = ""

  }
  if (!document.getElementById("en-loader").classList.contains("hide")) {
    toggle_loader()
  }

}

function change_elem(v) {
  var elem_dic = {}
  var elem_key = []
  var elem_value = []
  for (const [k, v] of Object.entries(elements)) {
    elem_value.push(JSON.parse(JSON.stringify(v)))
    elem_key.push(k)
  }
  elem_dic.key = elem_key
  elem_dic.value = elem_value



  var class_dic = {}
  var class_key = []
  var class_value = []
  for (const [k, v] of Object.entries(classes)) {
    class_value.push(JSON.parse(JSON.stringify(v)))
    class_key.push(k)
  }
  class_dic.key = class_key
  class_dic.value = class_value


  var anim_dic = {}
  var anim_key = []
  var anim_value = []
  for (const [k, v] of Object.entries(animations)) {
    anim_value.push(JSON.parse(JSON.stringify(v)))
    anim_key.push(k)
  }
  anim_dic.key = anim_key
  anim_dic.value = anim_value
  data.customelems[currentPage].elements = elem_dic
  data.customelems[currentPage].classes = class_dic
  data.customelems[currentPage].animations = anim_dic
  currentPage = v

  pageData = data.customelems[currentPage]

  if (data.customelems[currentPage].elements != null && Object.keys(data.customelems[currentPage].elements).length != 0) {
    elements = data.customelems[currentPage].elements
    pageElements = createDict(pageData.elements.key, pageData.elements.value)
    pageClasses = createDict(pageData.classes.key, pageData.classes.value)
    pageAnim = createDict(pageData.animations.key, pageData.animations.value)
    load_page_data()

  } else {
    let k = Object.keys(elements)[0],
      v = Object.values(elements)[0]
    elements = {}
    elements[k] = v
    document.getElementById("live-page").innerHTML = ""

  }
  if (!document.getElementById("en-loader").classList.contains("hide")) {
    toggle_loader()
  }

}

function createDict(keys, values) {
  let obj = {};
  for (let i = 0; i < keys.length; i++) {
    obj[keys[i]] = values[i] != undefined ? values[i] : null;
  }
  return obj
}

function add_page() {
  var pname = prompt("Enter Page name:")
  if (pname != null && pname != "") {
    data[pids].pages[pname] = { "elements": {} }
    pages.push(pname)
    if (pages.length == 1) {
      currentPage = pages[0]
      pageData = data[pid].pages[currentPage]
      if (data[pid].pages[currentPage].elements != null && Object.keys(data[pid].pages[currentPage].elements).length != 0) {
        elements = data[pid].pages[currentPage].elements
        pageElements = createDict(pageData.elements.key, pageData.elements.value)
        pageClasses = createDict(pageData.classes.key, pageData.classes.value)
        pageAnim = createDict(pageData.animations.key, pageData.animations.value)
        load_page_data()
      }
    }
    load_pages()
    if (!document.getElementById("en-loader").classList.contains("hide")) {
      toggle_loader()
    }

  }


}

function add_celems() {
  var pname = prompt("Enter Element name:")
  if (pname != null && pname != "") {
    data.customelems[pname] = { "elements": {} }
    pages.push(pname)
    if (pages.length == 1) {
      currentPage = pages[0]
      pageData = data.customelems[currentPage]
      if (data.customelems[currentPage].elements != null && Object.keys(data.customelems[currentPage].elements).length != 0) {
        elements = data.customelems[currentPage].elements
        pageElements = createDict(pageData.elements.key, pageData.elements.value)
        pageClasses = createDict(pageData.classes.key, pageData.classes.value)
        pageAnim = createDict(pageData.animations.key, pageData.animations.value)
        load_page_data()
      }
    }
    load_pages()
    if (!document.getElementById("en-loader").classList.contains("hide")) {
      toggle_loader()
    }
  }
}

function delete_celem() {
  if (pages.length != 0) {
    var confirm = window.confirm("Are you sure on deleting the current Element?")
    if (confirm) {
      toggle_loader()
      pages = pages.slice(0, pages.indexOf(currentPage)).concat(pages.slice((pages.indexOf(currentPage) + 1), (pages.length)))
      delete data.customelems[currentPage]
      if (pages.length == 0) {
        document.getElementById("en-live-page").innerHTML = ""
        elements = {}
        animations = {}
        classes = {}
        current = "en-live-page"
        load_pages()
        set_load_msg("Add a Page to start Editing")


      } else {
        currentPage = pages[0]
        pageData = data.customelems[currentPage]
        if (data.customelems[currentPage].elements != null && Object.keys(data.customelems[currentPage].elements).length != 0) {
          elements = data.customelems[currentPage].elements
          pageElements = createDict(pageData.elements.key, pageData.elements.value)
          pageClasses = createDict(pageData.classes.key, pageData.classes.value)
          pageAnim = createDict(pageData.animations.key, pageData.animations.value)
          document.getElementById("en-loader").classList.remove("hide")
          load_page_data()
          load_pages()
          toggle_loader()


        } else {
          document.getElementById("en-live-page").innerHTML = ""
          animations = {}
          classes = {}
          currentPage = pages[0]
          current = "en-live-page"
          var templ = new section("live-page")
          elements["live-page"] = templ
          elements["live-page"].element.childof = "en-live-page"
          elements["live-page"].element.Ename = "section"
          elements["live-page"].element.html.classList.add("en-live-page")
          elements["live-page"].element.html.addEventListener("drop", () => { en_drop(event) })
          elements["live-page"].element.html.addEventListener("dragover", () => { en_allowDrop(event) })
          elements["live-page"].element.html.addEventListener("dragleave", () => { en_endDrop(event) })
          elements["live-page"].element.html.addEventListener("dragend", () => { en_endDrop(event) })
          elements["live-page"].element.reload_element()
          current = "live-page"
          toggle_loader()
          load_pages()

        }
      }
    }
  }
}


function delete_page() {
  if (pages.length != 0) {
    var confirm = window.confirm("Are you sure on deleting the current page?")
    if (confirm) {
      toggle_loader()
      let np = []
      for (const [k, v] of Object.entries(pages)) {
        if (currentPage != v) {
          np.push(v)
        }
      }
      pages = np
      delete data[pids].pages[currentPage]
      console.log(pages)
      if (pages.length == 0) {
        document.getElementById("live-page").innerHTML = ""
        load_pages()
        set_load_msg("Add a Page to start Editing")


      } else {
        currentPage = pages[0]
        pageData = data[pids].pages[currentPage]
        console.log('pageData')

        console.log(pageData)
        if (data[pids].pages[currentPage].elements != null && Object.keys(data[pids].pages[currentPage].elements).length != 0) {
          elements = data[pids].pages[currentPage].elements
          pageElements = createDict(pageData.elements.key, pageData.elements.value)
          pageClasses = createDict(pageData.classes.key, pageData.classes.value)
          pageAnim = createDict(pageData.animations.key, pageData.animations.value)
          document.getElementById("en-loader").classList.remove("hide")
          load_page_data()
          load_pages()
          toggle_loader()


        } else {
          let k = Object.keys(elements)[0],
            v = Object.values(elements)[0]
          elements = {}
          elements[k] = v
          document.getElementById("live-page").innerHTML = ""
          load_pages()
          toggle_loader()


        }
      }
    }
  }
}



built = ["heading", "paragraph", "input", "button", "section", "Link", "img"]
var avail_properties = { 'Content (HTML)': "innerHTML", 'Content (TEXT)': "innerText", 'Placeholder': "placeholder", 'URL': "URL", 'Image': "SRC", }
var avail_styles = { 'Animation Name': "AnimationName", 'Animation Duration': "AnimationDuration", 'Background blur': "Bgblur", 'Padding': "Padding", 'Margin': "Margin", 'Display as': "Display", 'Text Style': "TextStyle", 'Background Color': "BackgroundColor", 'Flex Direction': "FlexDirection", 'Border Radius': "BorderRadius", 'Width': "Width", 'Height': "Height", 'Aling content': "AlignItems", 'Justify Content': "JustifyContent" }

var style = []



function load_list() {
  let html = ``
  for (const [i, val] of Object.entries(built)) {
    html += `
        
       <div draggable="true" ondragstart="en_drag(event,'` + val + `')" class="en-l-tab-element" onclick="add(event,'` + val + `')">` + val + `</div>
       `
  }
  document.getElementById("en-l-tab-elements").insertAdjacentHTML("beforeend", html)
}

function load_custom_elems() {
  html = ''
  for (const [i, v] of Object.entries(celem_list)) {
    html += `
        
       <div draggable="true" ondragstart="en_drag(event,'` + v + `','y')" class="en-l-tab-element" onclick="add_celem(event,'` + v + `')">` + v + `</div>
       `
  }
  document.getElementById("en-l-tab-custom-elements").insertAdjacentHTML("beforeend", html)
}
if (!location.pathname.includes("/download")) {
  load_list()
  load_custom_elems()
}




function toggle_loader() {
  document.getElementById("en-loader").classList.toggle("hide")
}

function set_load_msg(v) {
  document.getElementById("en-loader-msg").innerText = v

}

function add(e, tag) {
  let id = tag + "-" + uniqueId()
  while (elements[id] != null) {
    id = tag + "-" + uniqueId()

  }
  elements[current].element.childs[Object.keys(elements[current].element.childs).length + 1] = id

  elements[id] = eval("new " + tag + "(id)")
  elements[id].element.childof = current
  elements[id].element.Ename = tag
  en_set_style(current, id)
  current = id
  load_elements()

}

const uniqueId = () => {
  const dateString = Date.now().toString(36);
  const randomness = Math.random().toString(36).substr(2);
  var uid = dateString + randomness
  return uid;
};

function en_set_style(bid, aid) {
  try {
    let v = document.getElementsByClassName("en-sel")
    for (const [i, d] of Object.entries(v)) {
      document.getElementById(d.id).classList.remove("en-sel")
    }
    document.getElementById(aid).classList.add("en-sel")
  }
  catch (e) {
    console.log(e)
  }
}

function reload_elements() {
  for (const [a, b] of Object.entries(elements)) {
    b.element.reload_element()
  }
}

function change_property(id, name, val, type = '') {

  if (type == 'switch') {
    elements[id].element.set_switch_property([name, val])
  } else {
    elements[id].element.set_property([name, val])
  }

}

function change_switch_property(o, id, name, val) {
  elements[id].element.set_switch_property([o, name, val])
}


function change_style(id, name, val, an) {
  if (typeof(val) == 'boolean') {
    if (!an) {
      if (id != 'null') {
        let vl = elements[id].element.styles[name].style.link
        if (vl) {
          elements[id].element.styles[name].style.link = false
        } else {
          elements[id].element.styles[name].style.link = true
        }
      } else {
        let vl = classes[cclass].styles[name].style.link
        if (vl) {
          classes[cclass].styles[name].style.link = false
        } else {
          classes[cclass].styles[name].style.link = true
        }
      }
    } else {
      let sp = id.split('-')
      let k = sp[sp.length - 1]
      let vl = animations[cur_anim].keyframes[k][sp[0]].style.link
      if (vl) {
        animations[cur_anim].keyframes[k][sp[0]].style.link = false
      } else {
        animations[cur_anim].keyframes[k][sp[0]].style.link = true
      }

    }
  } else {
    if (!an) {
      if (id != 'null') {
        elements[id].element.set_style([name, val])
      } else {
        classes[cclass].styles[name].style.value = val
        reload_elements()
      }
    } else {
      let sp = id.split('-')
      let k = sp[sp.length - 1]
      animations[cur_anim].keyframes[k][sp[0]].style.value = val
      reload_css_anim()
    }
  }
}

function change_sub_style(o, id, name, val, an) {
  if (!an) {
    if (id != 'null') {
      elements[id].element.set_sub_style([o, name, val])
    } else {
      classes[cclass].styles[o].style.options[name].style.value = val
      let d = classes[cclass].styles[o]
      if (d.style.link_type && d.style.link) {
        let inputs = d.style.options
        for (const [i, v] of Object.entries(inputs)) {
          document.getElementById(d.style.options[i].style.title).value = val
          d.style.options[i].style.value = val
        }
      }
      reload_elements()
    }
  } else {
    let sp = id.split('-')
    let k = sp[sp.length - 1]
    animations[cur_anim].keyframes[k][sp[0]].style.options[name].style.value = val
    let d = animations[cur_anim].keyframes[k][sp[0]]
    if (d.style.link_type && d.style.link) {
      let inputs = d.style.options
      for (const [i, v] of Object.entries(inputs)) {
        document.getElementById(d.style.options[i].style.title).value = val
        d.style.options[i].style.value = val
      }
    }
    reload_css_anim()
  }
}

function convert_data(id, name, val, an) {
  //display
  if (id != 'null') {
    change_style(id, name, val, an)
  } else {
    reload_elements()
  }

}

function convert_sub_data(o, id, name, val, an) {
  //display
  change_sub_style(o, id, name, val, an)

}

function load_property(e, type, id) {
  if (type == "load") {
    let cid = ''
    if (e == null) {
      cid = id
    } else {
      cid = e.target.id
    }
    en_set_style(cid, id)
    current = cid
    nav_child(e, current)
    elements[cid].element.get_property()
  } else if (type = "delete") {
    current = id
    nav_child(e, current)
    elements[current].element.get_property()

  }
  elements[current].element.get_class()



}

function set_current(id) {
  current = id
}


//UI
var tab_head = ["Elements", "Custom Elements", "Navigate", "Properties", "Classes", "Animation"]
var tabs = ["en-l-tab-elements", "en-l-tab-custom-elements", "en-l-tab-nav", "en-l-tab-properties", "en-l-tab-style", "en-l-tab-anim"]
var bt_tabs = ["en0", "en1", "en2", "en3", "en4", "en5"]
var tab_id = ["ei0", "ei1", "ei2", "ei3", "ei4", "ei5"]
var tab_i = ["fi-rr-apps", "fi-rr-chart-simple-horizontal", "fi-rr-menu-burger", "fi-rr-settings", "fi-rr-list", "fi-rr-time-quarter-to"]
var tab_ia = ["fi-sr-apps", "fi-sr-chart-simple-horizontal", "fi-sr-menu-burger", "fi-sr-settings", "fi-sr-list", "fi-sr-time-quarter-to"]
if (location.pathname.includes("customElements")) {
  document.getElementById("en1").style.display = "none"
}
if (location.pathname.includes("offline")) {

  document.getElementById("en1").style.display = "none"

}

function change(i) {
  for (const [ind, v] of Object.entries(tabs)) {
    document.getElementById(v).style.display = "none"

  }
  for (const [ind, v] of Object.entries(bt_tabs)) {
    document.getElementById(v).classList.remove("tab-active")

  }
  for (const [ind, v] of Object.entries(tab_id)) {
    document.getElementById(v).classList.remove(tab_ia[ind])
    document.getElementById(v).classList.remove(tab_i[ind])
    document.getElementById(v).classList.add(tab_i[ind])

  }
  document.getElementById(tab_id[i]).classList.remove(tab_i[i])
  document.getElementById(tab_id[i]).classList.add(tab_ia[i])

  document.getElementById(tabs[i]).style.display = "flex"
  document.getElementById("en-l-tab-head").innerText = tab_head[i]
  document.getElementById(bt_tabs[i]).classList.add("tab-active")
}

function load_elements() {
  let html = ""
  let elems = document.getElementById(current).children
  for (const [i, elem] of Object.entries(elems)) {
    html += `
            <div id="en-child" onclick="nav_child(event,` + elem.id + `)">
                <p>` + elem.id.split("-")[0] + `</p>
            </div>
        `
  }
  if (current != "live-page") {
    document.getElementById("en-cur-p").innerText = current.split("-")[0]
  } else {
    document.getElementById("en-cur-p").innerText = current
    document.getElementById("en-e-cur-p").value = current.split("-")[0]

  }
  document.getElementById("en-e-cur-p").value = current.split("-")[0]
  if (current == "live-page") {
    document.getElementById("en-b-e-t").style.display = "none"
  } else {
    document.getElementById("en-b-e-t").style.display = "block"

  }
  document.getElementById("en-childs").innerHTML = html
  if (current === "live-page") {
    document.getElementById("en-l-i").style.display = "none"
  }
  else {
    document.getElementById("en-l-i").style.display = "inline"

  }
}
if (!location.pathname.includes("/download")) {
  load_elements()
}

function download_proj() {

  let d = JSON.stringify(data[pids])

  var a = document.createElement("a");
  a.href = window.URL.createObjectURL(new Blob([d], { type: "text/plain" }));
  a.download = name + ".dat";
  a.click();
}

function nav_parent() {
  let html = ""
  let elems = elements[elements[current].element.childof].element.childs
  for (const [i, elem] of Object.entries(elems)) {
    html += `
            <div id="en-child" onclick="nav_child(event,'` + elem + `')">
                <p>` + elem.split("-")[0] + `</p>
            </div>
        `
  }
  en_set_style(current, elements[current].element.childof)
  current = elements[current].element.childof

  if (current != "live-page") {
    document.getElementById("en-cur-p").innerText = current.split("-")[0]
  } else {
    document.getElementById("en-cur-p").innerText = current
    document.getElementById("en-e-cur-p").value = current.split("-")[0]

  }
  document.getElementById("en-e-cur-p").value = current.split("-")[0]
  if (current == "live-page") {
    document.getElementById("en-b-e-t").style.display = "none"
  } else {
    document.getElementById("en-b-e-t").style.display = "block"

  }
  document.getElementById("en-childs").innerHTML = html
  if (current === "live-page") {
    document.getElementById("en-l-i").style.display = "none"
  }
  else {
    document.getElementById("en-l-i").style.display = "inline"

  }
  let did = current

  if (current != 'live-page') {

    did = current.split("-")[0]
  }
  document.getElementById('en-tab-prop-sel').innerHTML = 'Editing : ' + did
}

function en_a_rename() {
  if (document.getElementById("en-e-cur-p").value != "") {
    var e = elements[current]
    let nid = document.getElementById("en-e-cur-p").value + "-" + current.split("-")[1]
    let oid = current
    e.element.html.id = nid
    e.element.ref.id = nid
    e.element.id = nid
    delete elements[current]
    elements[nid] = e
    elements[elements[nid].element.childof].element.childs[Object.values(elements[nid].element.childs)[Object.keys(elements[nid].element.childs).indexOf(oid)]] = nid
    for (const [k, v] of Object.entries(elements[nid].element.childs)) {
      elements[v].element.childof = nid
    }
    for (const [k, v] of Object.entries(elements[nid].properties)) {
      v.property.elemid = nid
    }
    for (const [k, v] of Object.entries(elements[nid].styles)) {
      v.style.elemid = nid
      if (v.style.type == "multiple") {
        for (const [a, b] of Object.entries(v.style.options)) {
          b.style.elemid = nid
        }

      }
    }
    document.getElementById("en-c-edit-ne").style.display = "flex";
    document.getElementById("en-c-edit-e").style.display = "none"
    current = nid
    nav_child(e, current)
  }
}

function nav_child(e, id) {
  let html = ""
  let elems = elements[id].element.childs
  for (const [i, elem] of Object.entries(elems)) {
    html += `
            <div id="en-child" onclick="nav_child(event,'` + elem + `')">
                <p>` + elem.split("-")[0] + `</p>
            </div>
        `
  }
  en_set_style(current, id)
  current = id
  if (current != "live-page") {
    document.getElementById("en-cur-p").innerText = current.split("-")[0]
  } else {
    document.getElementById("en-cur-p").innerText = current
    document.getElementById("en-e-cur-p").value = current.split("-")[0]

  }
  document.getElementById("en-e-cur-p").value = current.split("-")[0]
  if (current == "live-page") {
    document.getElementById("en-b-e-t").style.display = "none"
  } else {
    document.getElementById("en-b-e-t").style.display = "block"

  }
  document.getElementById("en-childs").innerHTML = html
  if (current === "live-page") {
    document.getElementById("en-l-i").style.display = "none"
  }
  else {
    document.getElementById("en-l-i").style.display = "inline"

  }
  let did = current
  if (current != 'live-page') {
    did = current.split("-")[0]
  }
  document.getElementById('en-tab-prop-sel').innerHTML = 'Editing : ' + did
}

function en_allowDrop(ev) {
  ev.preventDefault();
  document.getElementById(ev.target.id).classList.add("en_drop")
}


function en_endDrop(ev) {
  ev.preventDefault();
  document.getElementById(ev.target.id).classList.remove("en_drop")
}

function en_drag(ev, tag, cel = "n") {
  ev.dataTransfer.setData("tag", tag);
  ev.dataTransfer.setData("cel", cel);
}

function en_drop(ev) {
  ev.preventDefault();
  var datag = ev.dataTransfer.getData("tag");
  var cel = ev.dataTransfer.getData("cel");
  if (cel != "y") {
    en_set_style(current, ev.target.id)
    current = ev.target.id
    add(event, datag)
    document.getElementById(ev.target.id).classList.remove("en_drop")
  } else {
    current = ev.target.id
    add_celem(datag)
  }
}


function es_class(v) {
  elements[current].element.classes = v
  elements[current].element.html.removeAttribute('style')
  elements[current].element.ref.removeAttribute('style')
  elements[current].element.reload_element()
}



function generate_html(currentPage) {
  document.getElementById("preview").innerHTML = ""
  for (const [k, v] of Object.entries(elements)) {
    if (k != "live-page") {
      if (v.element.classes != '') {
        v.element.html.classList.add(v.element.classes)
      }
      document.getElementById(v.element.childof).appendChild(v.element.html)

    } else {
      if (v.element.classes != '') {
        v.element.html.classList.add(v.element.classes)
      }
      document.getElementById("preview").appendChild(v.element.html)

    }
  }
  var styles = ``
  for (const [k, v] of Object.entries(classes)) {
    var cl_st = ''
    for (const [a, b] of Object.entries(v.styles)) {
      cl_st += "\n" + b.style.get_css()
    }
    styles += `\n .` + k + `{` + cl_st + `}`
  }


  var anim = ``
  for (const [k, v] of Object.entries(animations)) {
    var cl_st = load_css_anim_g(v.duration, v.keyframes, v.name)
    anim += `\n` + cl_st
  }

  var pageHTML = `<!DOCTYPE html>

    <html>
    
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>` + pids + ` - ` + currentPage + `</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="styles/engine.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Sora&display=swap" rel="stylesheet">
    </head>
    <style>
    *{padding:0;margin:0;}
    body,html{width:100%;height:100%;font-family: 'Sora', sans-serif;}
    ` + styles + anim + `
    </style>
    <body>
    ` + document.getElementById("preview").innerHTML + `
    </body>
    </html>
    `
  return pageHTML
}

function en_s_rename() {
  document.getElementById("en-c-edit-ne").style.display = "none";
  document.getElementById("en-c-edit-e").style.display = "flex"
}

function add_celem(tag) {
  add_ceclass(createDict(data.customelems[tag].classes.key, data.customelems[tag].classes.value))
  add_ceanim(createDict(data.customelems[tag].animations.key, data.customelems[tag].animations.value))
  var elemdata = createDict(data.customelems[tag].elements.key, data.customelems[tag].elements.value)
  var pod = {
    [current]: current
  }
  for (const [k, v] of Object.entries(elemdata)) {
    if (v.element.id != "live-page") {

      var cid = v.element.id
      if (elements[cid] != null) {
        cid = v.element.Ename + "-" + uniqueId()
      }
      current = pod[v.element.childof]
      let cd = current
      elements[cid] = eval("new " + v.element.Ename + "(cid)")
      elements[cid].element.id = cid
      elements[cid].element.classes = v.element.classes
      elements[cid].element.childof = cd
      elements[cid].element.Ename = v.element.Ename
      let np = {}
      let dp = v.properties
      let ns = {}
      let ds = v.styles
      for (const [a, b] of Object.entries(dp)) {
        np[a] = eval("new " + b.property.nclass + "(cid)")
        np[a].property.value = b.property.value
      }
      for (const [a, b] of Object.entries(ds)) {
        ns[a] = eval("new " + b.style.nclass + "(cid)")
        if (ns[a].style.type == "multiple") {
          for (const [c, d] of Object.entries(ns[a].style.options)) {
            d.style.value = b.style.options[c].style.value
          }
        } else {
          ns[a].style.value = b.style.value
        }
      }
      elements[cid].properties = np
      elements[cid].element.properties = np
      elements[cid].styles = ns
      elements[cid].element.styles = ns
      elements[cid].element.reload_element()
      elements[cd].element.childs[Object.keys(elements[cd].element.childs).length + 1] = cid
      pod[v.element.id] = cid
    }
  }
  current = Object.keys(elements)[0]
  if (current != "") {
    elements[current].element.get_class()
  }


}



function load_page_data() {
  load_page_classes()
  current = "en-live-page"
  elements = {}
  document.getElementById("en-live-page").innerHTML = ""
  var data = pageElements["live-page"]
  current = data.element.childof
  var cid = data.element.id

  elements[cid] = eval("new " + data.element.Ename + "(cid)")

  elements[cid].element.id = cid
  elements[cid].element.classes = data.element.classes
  elements[cid].element.childof = data.element.childof
  elements[cid].element.childs = data.element.childs
  elements[cid].element.Ename = data.element.Ename
  let np = {}
  let dp = data.properties
  let ns = {}
  let ds = data.styles
  for (const [a, b] of Object.entries(dp)) {
    np[a] = eval("new " + b.property.nclass + "(cid)")
    np[a].property.value = b.property.value
  }
  for (const [a, b] of Object.entries(ds)) {
    ns[a] = eval("new " + b.style.nclass + "(cid)")
    if (ns[a].style.type == "multiple") {
      for (const [c, d] of Object.entries(ns[a].style.options)) {
        d.style.value = b.style.options[c].style.value
      }
    } else {
      ns[a].style.value = b.style.value
    }
  }
  elements[cid].properties = np
  elements[cid].element.properties = np
  elements[cid].styles = ns
  elements[cid].element.styles = ns
  elements["live-page"].element.html.classList.add("en-live-page")
  elements["live-page"].element.html.addEventListener("drop", () => { en_drop(event) })
  elements["live-page"].element.html.addEventListener("dragover", () => { en_allowDrop(event) })
  elements["live-page"].element.html.addEventListener("dragleave", () => { en_endDrop(event) })
  elements["live-page"].element.html.addEventListener("dragend", () => { en_endDrop(event) })
  elements["live-page"].element.reload_element()
  load_childs(pageElements["live-page"].element.childs)
  current = Object.keys(elements)[0]
  if (current != "") {
    elements[current].element.get_class()
  }

  load_property(event, "delete", Object.keys(elements)[0])
  let did = current
  if (current != 'live-page') {
    did = current.split("-")[0]
  }
  document.getElementById('en-tab-prop-sel').innerHTML = 'Editing : ' + did
}

function load_childs(v) {
  for (var i = 1; i <= Object.keys(v).length; i++) {
    var data = pageElements[v[i]]
    console.log(data)
    current = data.element.childof
    var cid = data.element.id

    elements[cid] = eval("new " + data.element.Ename + "(cid)")

    elements[cid].element.id = cid
    elements[cid].element.classes = data.element.classes
    elements[cid].element.childof = data.element.childof
    elements[cid].element.childs = data.element.childs
    elements[cid].element.Ename = data.element.Ename
    let np = {}
    let dp = data.properties
    let ns = {}
    let ds = data.styles
    for (const [a, b] of Object.entries(dp)) {
      np[a] = eval("new " + b.property.nclass + "(cid)")
      np[a].property.value = b.property.value
    }
    for (const [a, b] of Object.entries(ds)) {
      ns[a] = eval("new " + b.style.nclass + "(cid)")
      if (ns[a].style.type == "multiple") {
        for (const [c, d] of Object.entries(ns[a].style.options)) {
          d.style.value = b.style.options[c].style.value
        }
      } else {
        ns[a].style.value = b.style.value
      }
    }
    elements[cid].properties = np
    elements[cid].element.properties = np
    elements[cid].styles = ns
    elements[cid].element.styles = ns
    elements[cid].element.reload_element()
    load_childs(elements[cid].element.childs)
  }

}

function load_parent(data) {
  var k = current
  var v = data
  current = v.element.childof
  if (current != "en-live-page") {
    if (elements[current] != null) {
      elements[k] = eval("new " + v.element.Ename + "(v.element.id)")
    }
    else {
      load_parent(pageData.elements[current])
      elements[k] = eval("new " + v.element.Ename + "(v.element.id)")
    }
  } else {

    elements[k] = eval("new " + v.element.Ename + "(v.element.id)")
  }
  elements[k].element.id = v.element.id
  elements[k].element.classes = v.element.classes
  elements[k].element.childof = v.element.childof
  let ch = {}
  for (const [k, v] of Object.entries(v.element.childs)) {
    ch[k] = v
  }
  elements[k].element.childs = ch
  elements[k].element.Ename = v.element.Ename
  let np = {}
  let dp = v.properties
  let ns = {}
  let ds = v.styles
  for (const [a, b] of Object.entries(dp)) {
    np[a] = eval("new " + b.property.nclass + "(v.element.id)")
    np[a].property.value = b.property.value
  }
  for (const [a, b] of Object.entries(ds)) {
    ns[a] = eval("new " + b.style.nclass + "(v.element.id)")
    if (ns[a].style.options != null && ns[a].style.options["c1"] == null) {
      for (const [c, d] of Object.entries(ns[a].style.options)) {
        d.style.value = b.style.options[c].style.value
      }
    } else {
      ns[a].style.value = b.style.value
    }
  }
  elements[k].properties = np
  elements[k].element.properties = np
  elements[k].styles = ns
  elements[k].element.styles = ns
  elements[k].element.reload_element()

}



//Main Element class
class Element {
  constructor(tag, id, classes, properties, styles, childof = "", childs = {}, setup = true, Ename = "") {
    this.tag = tag
    this.id = id
    this.classes = classes
    this.styles = styles
    this.properties = properties
    this.html = document.createElement(tag)
    this.html.id = id
    this.childof = childof
    this.ref = document.createElement(tag)
    this.ref.id = id
    this.childs = childs
    this.Ename = Ename
    this.ref.onclick = () => {
      load_property(event, "load", this.id)
      change(3)
    }
    if (setup) {
      this.set_up_element()
    }
  }


  get_class() {
    let p_html = `<option vlaue='` + this.classes + `'>` + this.classes + `</option>`
    let vh = ''
    if (this.classes == "" || this.classes == null) {
      p_html = ""
    }
    vh = "<option vlaue=''>Select a Class</option>"
    let html = ''
    for (const [a, b] of Object.entries(classes)) {
      if (a != this.classes) {
        html += `<option value='` + a + `'>` + a + `</option>`
      }
    }
    let fhtml = ''
    if (p_html == "") {
      fhtml = vh + html
    } else {
      fhtml = p_html + html + vh
    }
    document.getElementById("cen_curr").innerHTML = fhtml
    if (this.classes != null && this.classes != "") {
      document.getElementById("cen_curr").value = this.classes
    }

  }


  set_up_element() {
    let property_HTML = ``
    if (this.classes != "" && this.classes != "Select a Class" && this.classes != null) {
      for (const [property, obj] of Object.entries(classes[this.classes].styles)) {
        if (obj.style.type == "multiple") {

          for (const [property, obj1] of Object.entries(obj.style.options)) {

            eval("this.ref.style." + obj1.style.js + "='" + obj1.style.value + "'")

          }
        }

        else {


          if (obj.style.options != null && obj.style.options.c1 == "custom") {
            eval("this.ref.style." + obj.style.js + "='" + obj.style.options.c2 + "(" + obj.style.value + ")'")

          } else {

            eval("this.ref.style." + obj.style.js + "='" + obj.style.value + "'")
          }
        }
      }
    }
    for (const [property, obj] of Object.entries(this.properties)) {

      if (obj.property.type == 'image') {

        var dat = null

        dat = window.URL.createObjectURL(obj.property.value)

        eval("this.html." + obj.property.js + "='" + dat + "'")



        eval("this.ref." + obj.property.js + "='" + dat + "'")


      }
      else if (obj.property.type == 'switch') {
        eval("this.html." + obj.property.js + "='" + obj.property.options[obj.property.sc].value + "'")

        eval("this.ref." + obj.property.js + "='" + obj.property.options[obj.property.sc].value + "'")
      }
      else {
        eval("this.html." + obj.property.js + "='" + obj.property.value + "'")

        eval("this.ref." + obj.property.js + "='" + obj.property.value + "'")

      }
      property_HTML += obj.property.propertyHTML()
    }
    for (const [property, obj] of Object.entries(this.styles)) {
      eval("this.html.style." + obj.style.js + "='" + obj.style.value + "'")
      eval("this.ref.style." + obj.style.js + "='" + obj.style.value + "'")
      property_HTML += obj.style.propertyHTML()
    }
    document.getElementById(current).appendChild(this.ref)
    document.getElementById("en-l-tab-properties-conatainer").innerHTML = ""
    document.getElementById("en-l-tab-properties-conatainer").insertAdjacentHTML("beforeend", property_HTML)

    if (!location.pathname.includes("/download")) {
      change(3)
    }
  }

  get_property() {

    let property_HTML = ``
    for (const [property, obj] of Object.entries(this.properties)) {
      property_HTML += obj.property.propertyHTML()
    }
    for (const [property, obj] of Object.entries(this.styles)) {
      property_HTML += obj.style.propertyHTML()
    }
    for (const eclass of Object.entries(this.classes)) {
      //TODO
    }
    document.getElementById("en-l-tab-properties-conatainer").innerHTML = ""
    document.getElementById("en-l-tab-properties-conatainer").insertAdjacentHTML("beforeend", property_HTML)
  }

  reload_element() {
    if (this.classes != "" && this.classes != "Select a Class" && this.classes != null) {
      for (const [property, obj] of Object.entries(classes[this.classes].properties)) {
        eval("this.ref." + obj.property.js + "='" + obj.property.value + "'")
      }
      for (const [property, obj] of Object.entries(classes[this.classes].styles)) {
        if (obj.style.type == "multiple") {

          for (const [property, obj1] of Object.entries(obj.style.options)) {

            eval("this.ref.style." + obj1.style.js + "='" + obj1.style.value + "'")

          }
        } else {


          if (obj.style.options != null && obj.style.options.c1 == "custom") {
            eval("this.ref.style." + obj.style.js + "='" + obj.style.options.c2 + "(" + obj.style.value + ")'")

          } else {

            eval("this.ref.style." + obj.style.js + "='" + obj.style.value + "'")
          }
        }
      }
    }
    for (const [property, obj] of Object.entries(this.properties)) {
      if (obj.property.type == 'image') {



        var dat = null

        dat = window.URL.createObjectURL(obj.property.value)

        eval("this.html." + obj.property.js + "='" + dat + "'")



        eval("this.ref." + obj.property.js + "='" + dat + "'")


      }
      else if (obj.property.type == 'switch') {
        eval("this.html." + obj.property.js + "='" + obj.property.options[obj.property.sc].value + "'")

        eval("this.ref." + obj.property.js + "='" + obj.property.options[obj.property.sc].value + "'")
      }
      else {
        eval("this.html." + obj.property.js + "='" + obj.property.value + "'")

        eval("this.ref." + obj.property.js + "='" + obj.property.value + "'")

      }
    }
    for (const [property, obj] of Object.entries(this.styles)) {
      if (obj.style.type == "multiple") {

        for (const [property, obj1] of Object.entries(obj.style.options)) {

          eval("this.html.style." + obj1.style.js + "='" + obj1.style.value + "'")
          eval("this.ref.style." + obj1.style.js + "='" + obj1.style.value + "'")

        }
      } else {


        if (obj.style.options != null && obj.style.options.c1 == "custom") {
          eval("this.html.style." + obj.style.js + "='" + obj.style.options.c2 + "(" + obj.style.value + ")'")
          eval("this.ref.style." + obj.style.js + "='" + obj.style.options.c2 + "(" + obj.style.value + ")'")

        } else {

          eval("this.html.style." + obj.style.js + "='" + obj.style.value + "'")
          eval("this.ref.style." + obj.style.js + "='" + obj.style.value + "'")
        }
      }
    }
    for (const eclass of Object.entries(this.classes)) {
      //TODO
    }
  }

  element_live_HTML() {
    html = ""
    for (cont[i, val] of Object.entries(childs)) {
      html += document.getElementById(elements[val].element.id).outerHTML;
    }
  }

  element_get_list(l = []) {
    let id = this.id
    var list = {}
    list[id] = this.childof
    for (const [i, val] of Object.entries(this.childs)) {
      if (val in l != true) {
        list = Object.assign({}, list, elements[val].element.element_get_list(list))
      }

    }
    return list

  }

  set_property(data) {

    this.properties[data[0]].property.value = data[1]

    this.reload_element()
  }

  set_switch_property(data) {
    this.properties[data[0]].property.options[this.properties[data[0]].property.sc].value = data[1]

    this.reload_element()
  }


  set_style(data) {
    this.styles[data[0]].style.value = data[1]
    this.reload_element()
  }
  set_sub_style(data) {
    let d = this.styles[data[0]]
    d.style.options[data[1]].style.value = data[2]
    if (d.style.link_type && d.style.link) {
      let inputs = d.style.options
      for (const [i, v] of Object.entries(inputs)) {
        document.getElementById(d.style.options[i].style.title).value = data[2]
        d.style.options[i].style.value = data[2]
      }
    }
    this.reload_element()
  }

}

//Element classes
class heading {
  constructor(id) {
    this.properties = { "innerText": new innerText(id, "Heading", "Heading") }
    this.styles = {}
    this.element = new Element("h1", id, "", this.properties, this.styles)
  }


}

class paragraph {
  constructor(id) {
    this.properties = { "innerText": new innerText(id, "Paragraph", "Text") }
    this.styles = {}
    this.element = new Element("p", id, "", this.properties, this.styles)
  }


}
class Link {
  constructor(id) {
    this.properties = { "innerText": new innerText(id, "Link", "Text") }
    this.styles = {}
    this.element = new Element("a", id, "", this.properties, this.styles)
  }


}
class button {
  constructor(id) {
    this.properties = { "innerText": new innerText(id, "Button", "Text") }
    this.styles = {}
    this.element = new Element("button", id, "", this.properties, this.styles)
  }


}

class input {
  constructor(id) {
    this.properties = {}
    this.styles = {}
    this.element = new Element("input", id, "", this.properties, this.styles)
  }


}
class section {
  constructor(id) {
    this.properties = {}
    this.styles = {}
    this.element = new Element("div", id, "", this.properties, this.styles)
  }


}

class img {

  constructor(id) {

    this.properties = {}
    this.styles = {}
    this.element = new Element("img", id, "", this.properties, this.styles)
  }


}

function switch_input(id, name, val) {
  console.log(val)
  elements[id].properties[name].property.sc = val
  elements[id].element.get_property()

}


//Main Property Class
class Property {
  constructor(nclass, elemid, title, type, value, js, options = {}, sc = null) {
    this.elemid = elemid
    this.title = title
    this.type = type
    this.value = value
    this.js = js
    this.nclass = nclass
    this.options = options
    this.sc = sc
  }
  propertyHTML(o = null) {
    if (this.type == 'switch') {
      let op = this.options
      let op_html = op[this.sc].property.propertyHTML(this.nclass)
      let opt_ht = ''
      for (const [k, v] of Object.entries(op)) {
        opt_ht += `<option value='` + k + `'>` + v.property.title + `</option>`
      }
      let drop = `
      <select id='en-sel-media' oninput="switch_input('` + this.elemid + `','` + this.nclass + `',this.value,'` + this.type + `')" value='` + this.sc + `'>
        ` + opt_ht + `
      </select>
      `
      console.log(this.sc)
      html = drop + op_html

      return `            <div class="property-container-m">


        <h3>` + this.title + `</h3>

        ` + html + `
        <p class="en-del-prop" onclick="remove_prop('` + this.elemid + `','` + this.nclass + `')">Remove Attribute</p>
        </div>`
    } else {
      if (this.type == 'image') {
        var oi = ''

        if (o == null) {

          oi = `oninput="change_property('` + this.elemid + `','` + this.nclass + `',this.files[0],'` + this.type + `')"`
        } else {
          oi = `oninput="change_switch_property('` + o + `','` + this.elemid + `','` + this.nclass + `',this.files[0],'` + this.type + `')"`
        }
        var html = `
            <input placeholder="` + this.title + `" type="file"  ` + oi + ` files = "` + this.value + `" >`


      }
      else if (this.type == 'media') {
        var html = `
        <button style = 'margin:5px;padding:5px;'
      onclick = 'toggle_en_media(true)' >
        import from media </button>
      `



      }
      else {
        var oi = ''

        if (o == null) {

          oi = `oninput="change_property('` + this.elemid + `','` + this.nclass + `',this.value,'` + this.type + `')"`
        } else {
          oi = `oninput="change_switch_property('` + o + `','` + this.elemid + `','` + this.nclass + `',this.value,'` + this.type + `')"`
        }
        var html = ` <input placeholder = "` + this.title + `"
      type = "` + this.type + `"
       ` + oi + ` value="` + this.value + `">
            `


      }
      return `<div class="property-container">

        <h3>` + this.title + `</h3>

        ` + html + `
        <p class="en-del-prop" onclick="remove_prop('` + this.elemid + `','` + this.nclass + `')">Remove Attribute</p>
        </div>`
    }
  }

}

function remove_prop(id, c) {
  delete elements[id].element.properties[c]
  elements[id].element.reload_element()
  elements[id].element.get_property()

}

function remove_style(id, c) {
  delete elements[id].element.styles[c]
  elements[id].element.ref.removeAttribute("style")
  elements[id].element.html.removeAttribute("style")
  elements[id].element.reload_element()
  elements[id].element.get_property()

}


class Style {
  constructor(nclass, elemid, title, type, value, js, options = null, link = true, link_type = false, hover = false) {
    this.elemid = elemid
    this.title = title
    this.type = type
    this.value = value
    this.js = js
    this.options = options
    this.nclass = nclass
    this.link = link
    this.link_type = link_type
    this.hover = hover
  }
  propertyHTML(t = null, o = null, animat = false) {
    var html = '',
      linkbt = ''
    if (this.link_type) {
      linkbt = '<div class="property-container-m-i"><i onclick="change_style(`' + this.elemid + '`,`' + this.nclass + '`,' + this.link + ',' + animat + ')" class="fi-ss-link-horizontal "></i></div>'
    }
    if (t == null) {
      if (this.type == "dropdown") {
        let ophtml = ""
        let fhtml = ''
        for (const [i, val] of Object.entries(this.options)) {
          if (val == this.value) {
            fhtml = `<option value="` + val + `">` + val + `</option>`
          } else {
            ophtml += `<option value="` + val + `">` + val + `</option>`
          }
        }
        html = `<select id='` + this.title + `' value="` + this.value + `" oninput="convert_data('` + this.elemid + `','` + this.nclass + `',this.value,` + animat + `)">
            ` + fhtml + ophtml + `
            </select>
            
            `
        return `<div class="property-container">
        <h3>` + this.title + `</h3>
        ` + html + `
        <p class="en-del-prop" onclick="remove_style('` + this.elemid + `','` + this.nclass + `')">Remove Style</p>
        </div>

        `

      }

      else if (this.type == "multiple") {

        for (const [i, c] of Object.entries(this.options)) {
          html += c.style.propertyHTML("m", this.nclass, animat)
        }
        return `
            <h3>` + this.title + `</h3>
            ` + linkbt + `
            <div class="property-container-m">
            ` + html + `
            <p class="en-del-prop" onclick="remove_style('` + this.elemid + `','` + this.nclass + `')">Remove Style</p>
            </div>
    
            `

      }

      else {
        html = `
            <input  id='` + this.title + `' placeholder="` + this.title + `" type="` + this.type + `" oninput="change_style('` + this.elemid + `','` + this.nclass + `',this.value,` + animat + `)" value="` + this.value + `">
            `
        return `<div class="property-container">
        <h3>` + this.title + `</h3>
        ` + html + `
        <p class="en-del-prop" onclick="remove_style('` + this.elemid + `','` + this.nclass + `')">Remove Style</p>
        </div>

        `

      }
    }
    else {
      if (this.type == "dropdown") {
        let ophtml = ""
        let fhtml = ''
        for (const [i, val] of Object.entries(this.options)) {
          if (val == this.value) {
            fhtml = `<option value="` + val + `">` + val + `</option>`
          } else {
            ophtml += `<option value="` + val + `">` + val + `</option>`
          }
        }
        html = `<select  id='` + this.title + `' value="` + this.value + `" id="en_tem-c" oninput="convert_sub_data('` + o + `','` + this.elemid + `','` + this.nclass + `',this.value,` + animat + `)">
            ` + ophtml + `
            </select>
            
            `
        return `<div class="property-container-sm">
        <p>` + this.title + `</p>
        ` + fhtml + html + `
        </div>

        `

      } else {
        html = `
            <input id='` + this.title + `' placeholder="` + this.title + `" type="` + this.type + `" oninput="change_sub_style('` + o + `','` + this.elemid + `','` + this.nclass + `',this.value,` + animat + `)" value="` + this.value + `">
            `
        return `<div class="property-container-sm">
        <p>` + this.title + `</p>
        ` + html + `
        </div>

        `

      }

    }
  }

  get_css() {
    let css = ''
    if (this.type != "multiple") {
      if (this.value != "") {
        let cjs = ''
        for (var [i, st] of Object.entries(this.js)) {
          if (st == st.toUpperCase()) {
            let b = this.js.slice(0, i),
              a = this.js.slice(parseInt(i) + 1)
            cjs = b + "-" + st.toLowerCase() + a
          }
        }
        if (cjs != "") {
          css = cjs + " : " + this.value + ";\n"
        } else {
          css = this.js + " : " + this.value + ";\n"
        }
      }
    }
    else {

      for (const [k, v] of Object.entries(this.options)) {
        css += v.style.get_css() + "\n"
      }
    }

    return css
  }

}



//Property classes

class innerHTML {
  constructor(elemid, value = "", title = "innerHTML") {
    this.property = new Property("innerHTML", elemid, title, "text", value, "innerHTML")
  }
}

class srcURL {

  constructor(elemid, value = "", title = "Source (URL)") {

    this.property = new Property("srcURL", elemid, title, "text", value, "src")
  }
}

class srcFILE {

  constructor(elemid, value = "", title = "Source (FILE)") {

    this.property = new Property("srcFILE", elemid, title, "image", value, "src")
  }
}


class srcMEDIA {
  constructor(elemid, value = "", title = "Source (MEDIA)") {

    this.property = new Property("srcMEDIA", elemid, title, "media", value, "src")
  }
}

class SRC {
  constructor(elemid, value = "", title = "Source (MEDIA)") {



    this.property = new Property("SRC", elemid, title, "switch", value, "src", {
      "srcURL": new srcURL(elemid),
      'srcFILE': new srcFILE(elemid),
      'srcMEDIA': new srcMEDIA(elemid)
    }, "srcURL")
  }
}

class innerText {
  constructor(elemid, value = "", title = "innerText") {
    this.property = new Property("innerText", elemid, title, "text", value, "innerText")
  }
}

class placeholder {
  constructor(elemid, value = "", title = "plaeholder") {
    this.property = new Property("placeholder", elemid, title, "text", value, "placeholder")
  }
}

class Padding {
  constructor(elemid, value = "", title = "Padding") {
    this.style = new Style("Padding", elemid, title, "multiple", value, "padding", {
      "PaddingTop": new PaddingTop(elemid),
      "PaddingLeft": new PaddingLeft(elemid),
      "PaddingBottom": new PaddingBottom(elemid),
      "PaddingRight": new PaddingRight(elemid)
    }, true, true)
  }
}

class PaddingTop {
  constructor(elemid, value = "", title = "Top") {
    this.style = new Style("PaddingTop", elemid, title, "text", value, "paddingTop")
  }
}

class AnimationName {
  constructor(elemid, value = "", title = "Animation Name") {
    this.style = new Style("AnimationName", elemid, title, "text", value, "animationName")
  }
}
class AnimationDuration {
  constructor(elemid, value = "", title = "Animation Duration") {
    this.style = new Style("AnimationDuration", elemid, title, "text", value, "animationDuration")
  }
}

class PaddingLeft {
  constructor(elemid, value = "", title = "Left") {
    this.style = new Style("PaddingLeft", elemid, title, "text", value, "paddingLeft")
  }
}

class PaddingBottom {
  constructor(elemid, value = "", title = "Bottom") {
    this.style = new Style("PaddingBottom", elemid, title, "text", value, "paddingBottom")
  }
}

class PaddingRight {
  constructor(elemid, value = "", title = "Right") {
    this.style = new Style("PaddingRight", elemid, title, "text", value, "paddingRight")
  }
}


class Margin {
  constructor(elemid, value = "", title = "Margin") {
    this.style = new Style("Margin", elemid, title, "multiple", value, "margin", {
      "MarginTop": new MarginTop(elemid),
      "MarginBottom": new MarginBottom(elemid),
      "MarginLeft": new MarginLeft(elemid),
      "MarginRight": new MarginRight(elemid)
    }, true, true)
  }
}
class MarginBottom {
  constructor(elemid, value = "", title = "Bottom") {
    this.style = new Style("MarginBottom", elemid, title, "text", value, "marginBottom")
  }
}
class MarginTop {
  constructor(elemid, value = "", title = "Top") {
    this.style = new Style("MarginTop", elemid, title, "text", value, "marginTop")
  }
}
class MarginRight {
  constructor(elemid, value = "", title = "Right") {
    this.style = new Style("MarginRight", elemid, title, "text", value, "marginRight")
  }
}
class MarginLeft {
  constructor(elemid, value = "", title = "Left") {
    this.style = new Style("MarginLeft", elemid, title, "text", value, "marginLeft")
  }
}

class Width {
  constructor(elemid, value = "", title = "Width") {
    this.style = new Style("Width", elemid, title, "text", value, "width")
  }
}

class Height {
  constructor(elemid, value = "", title = "Height") {
    this.style = new Style("Height", elemid, title, "text", value, "height")
  }
}

class BorderRadius {
  constructor(elemid, value = "", title = "Border Radius") {
    this.style = new Style("BorderRadius", elemid, title, "text", value, "borderRadius")
  }
}

class Display {
  constructor(elemid, value = "", title = "Display") {
    this.style = new Style("Display", elemid, title, "dropdown", value, "display", ["block", "none", "flex", "inline"])
  }
}

class TextColor {
  constructor(elemid, value = "#000000", title = "Text Color") {
    this.style = new Style("TextColor", elemid, title, "color", value, "color")
  }

}
class BackgroundColor {
  constructor(elemid, value = "#ffffff", title = "Background Color") {
    this.style = new Style("BackgroundColor", elemid, title, "color", value, "backgroundColor")
  }

}
class JustifyContent { constructor(elemid, value = '', title = 'Horizontal Alignment') { this.style = new Style('JustifyContent', elemid, title, 'dropdown', value, 'justifyContent', ["none", "center", "start", "end"]) } }

class FlexDirection {
  constructor(elemid, value = "row", title = "Flex Arrangement") {
    this.style = new Style("FlexDirection", elemid, title, "dropdown", value, "flexDirection", ["row", "column", "row-reverse", "column-reverse"])
  }

}
class AlignItems {
  constructor(elemid, value = "None", title = "Align Items") {
    this.style = new Style("AlignItems", elemid, title, "dropdown", value, "alignItems", ["None", "center", "end"])
  }

}

class FontSize { constructor(elemid, value = '', title = 'Font Size') { this.style = new Style('FontSize', elemid, title, 'text', value, 'fontSize') } }

class TextStyle { constructor(elemid, value = '', title = 'Text Style') { this.style = new Style('TextStyle', elemid, title, 'multiple', value, 'js', { "FontSize": new FontSize(elemid), "TextColor": new TextColor(elemid) }) } }

class Bgblur { constructor(elemid, value = '', title = 'Background Blur') { this.style = new Style('Bgblur', elemid, title, 'text', value, 'backdropFilter', { "c1": "custom", "c2": "blur" }) } }





//document.getElementById().style.fontSize

//input types






var templ = new section("live-page")
elements["live-page"] = templ
elements["live-page"].element.childof = "en-live-page"
elements["live-page"].element.Ename = "section"
elements["live-page"].element.html.classList.add("en-live-page")
elements["live-page"].element.html.addEventListener("drop", () => { en_drop(event) })
elements["live-page"].element.html.addEventListener("dragover", () => { en_allowDrop(event) })
elements["live-page"].element.html.addEventListener("dragleave", () => { en_endDrop(event) })
elements["live-page"].element.html.addEventListener("dragend", () => { en_endDrop(event) })
elements["live-page"].element.reload_element()
current = "live-page"








//Menu
var menuid = ""

if (!location.pathname.includes("/download")) {
  if (document.addEventListener) {

    document.getElementById("en-live-page").addEventListener('contextmenu', function(e) {
      if (document.getElementById("en-move-overlay").style.display == "" || document.getElementById("en-move-overlay").style.display == "none") {
        menuid = e.target.id
        document.getElementById("en-menu").style.display = "flex";
        document.getElementById("en-menu").style.top = mouseY(event) + 'px';
        document.getElementById("en-menu").style.left = mouseX(event) + 'px';
      }
      e.preventDefault();
    }, false);
  } else {
    document.getElementById("en-live-page").attachEvent('oncontextmenu', function() {
      if (document.getElementById("en-move-overlay").style.display == "" || document.getElementById("en-move-overlay").style.display == "none") {
        document.getElementById("en-menu").style.display = "flex";
        document.getElementById("en-menu").style.top = mouseY(event) + 'px';
        document.getElementById("en-menu").style.left = mouseX(event) + 'px';
        window.event.returnValue = false;
      }
    });
  }
  document.getElementById("en-live-page").addEventListener("click", function(event) {
    if (document.getElementById("en-move-overlay").style.display == "" || document.getElementById("en-move-overlay").style.display == "none") {
      document.getElementById("en-menu").style.display = "none";
      document.getElementById("en-add-property").classList.remove("toggle-flex");
    }
  });

}

function mouseX(evt) {
  if (evt.pageX) {
    return evt.pageX;
  } else if (evt.clientX) {
    return evt.clientX + (document.documentElement.scrollLeft ?
      document.documentElement.scrollLeft :
      document.body.scrollLeft);
  } else {
    return null;
  }
}

function mouseY(evt) {
  if (evt.pageY) {
    return evt.pageY;
  } else if (evt.clientY) {
    return evt.clientY + (document.documentElement.scrollTop ?
      document.documentElement.scrollTop :
      document.body.scrollTop);
  } else {
    return null;
  }
}

function delete_element(event) {
  if (menuid != "live-page") {
    var currenti = document.getElementById(menuid).parentElement.id
    var oc = elements[currenti].element.childs,
      nc = []
    for (const [k, v] of Object.entries(oc)) {
      if (v != menuid) {
        nc[k] = v
      }
    }

    elements[currenti].element.childs = nc
    document.getElementById(menuid).remove()
    for (const [k, v] of Object.entries(elements[menuid].element.childs)) {
      delete elements[v]

    }
    load_property(event, "delete", currenti)
    delete elements[menuid]
  }
  document.getElementById("en-menu").style.display = "none";
}

function move_up(event) {
  var ch = elements[elements[menuid].element.childof].element.childs
  console.log(ch)
  for (const [i, v] of Object.entries(ch)) {
    if (v == menuid) {
      if (parseInt(i) != 0) {
        let u = ch[(parseInt(i) - 1)]
        console.log(ch[(parseInt(i) - 1)])
        ch[(parseInt(i) - 1)] = v
        console.log(v)
        ch[parseInt(i)] = u
      }
    }
  }
  let pem = document.getElementById(elements[menuid].element.childof)
  pem.innerHTML = ""
  elements[elements[menuid].element.childof].element.childs = ch
  for (const [i, v] of Object.entries(ch)) {
    pem.appendChild(elements[v].element.ref)
  }
  document.getElementById("en-menu").style.display = "none";
}

function move_down(event) {
  var ch = elements[elements[menuid].element.childof].element.childs
  for (const [i, v] of Object.entries(ch)) {
    if (v == menuid) {
      if (i != (ch.length - 1)) {
        u = ch[(parseInt(i))]
        ch[(parseInt(i))] = v
        ch[parseInt(i) - 1] = u
      }
    }
  }
  let pem = document.getElementById(elements[menuid].element.childof)
  pem.innerHTML = ""
  elements[elements[menuid].element.childof].element.childs = ch
  for (const [i, v] of Object.entries(ch)) {
    pem.appendChild(elements[v].element.ref)
  }
  document.getElementById("en-menu").style.display = "none";
}

function move_e(event) {
  let mid = event.target.id
  document.getElementById("live-page").removeEventListener("click", move_e)
  document.getElementById("en-add-property").classList.toggle("toggle-flex")
  if (mid != menuid && !document.getElementById(menuid).contains(document.getElementById(mid))) {
    let chm = elements[elements[menuid].element.childof].element.childs

    let nch = []

    for (const [k, v] of Object.entries(chm)) {
      if (v != menuid) {
        nch[k] = v
      }
    }

    elements[elements[menuid].element.childof].element.childs = nch



    elements[menuid].element.childof = mid
    elements[mid].element.childs[Object.keys(elements[mid].element.childs).length + 1] = menuid
    document.getElementById(menuid).remove()
    document.getElementById(mid).appendChild(elements[menuid].element.ref)
    document.getElementById("en-move-overlay").style.display = "none"
  }


}

function cancel_move(event) {
  document.getElementById("en-move-overlay").style.display = "none"

}

function move_to(event) {
  document.getElementById("en-move-overlay").style.display = "flex"
  document.getElementById("live-page").addEventListener("click", move_e)
  document.getElementById("en-menu").style.display = "none";
}

function en_show_add_prop() {
  let c_p = elements[current].element.properties
  let c_s = elements[current].element.styles
  let phtml = "<p class='en-prop-title'>Attributes</p>",
    shtml = '<p class="en-prop-title">Styles</p> '
  for (const [i, v] of Object.entries(avail_properties)) {
    if (v in c_p == false) {
      phtml += "<div style='cursor:pointer;' onclick='en_add_property(`" + v + "`)'>" + i + "</div>"
    }
  }
  for (const [i, v] of Object.entries(avail_styles)) {
    if (v in c_s == false) {
      shtml += "<div style='cursor:pointer;' onclick='en_add_style(`" + v + "`)'>" + i + "</div>"
    }
  }
  document.getElementById("en-add-property-con").innerHTML = ''
  document.getElementById("en-add-property-con").insertAdjacentHTML('beforeend', phtml)
  document.getElementById("en-add-property-con").insertAdjacentHTML('beforeend', shtml)
  document.getElementById("en-add-property").classList.toggle("toggle-flex")
}


function filt_prop(val) {
  let c_p = elements[current].element.properties
  let c_s = elements[current].element.styles
  let phtml = "<p class='en-prop-title'>Attributes</p>",
    shtml = '<p class="en-prop-title">Styles</p> '
  for (const [i, v] of Object.entries(avail_properties)) {
    if (v in c_p == false) {
      if (val != "") {
        if (v.toLowerCase().includes(val.toLowerCase())) {
          phtml += "<div style='cursor:pointer;' onclick='en_add_property(`" + v + "`)'>" + i + "</div>"
        }
      } else {
        phtml += "<div style='cursor:pointer;' onclick='en_add_property(`" + v + "`)'>" + i + "</div>"

      }
    }
  }
  for (const [i, v] of Object.entries(avail_styles)) {
    if (v in c_s == false) {
      if (val != "") {
        if (v.toLowerCase().includes(val.toLowerCase())) {

          shtml += "<div style='cursor:pointer;' onclick='en_add_style(`" + v + "`)'>" + i + "</div>"
        }
      } else {

        shtml += "<div style='cursor:pointer;' onclick='en_add_style(`" + v + "`)'>" + i + "</div>"
      }
    }
  }
  document.getElementById("en-add-property-con").innerHTML = ''
  document.getElementById("en-add-property-con").insertAdjacentHTML('beforeend', phtml)
  document.getElementById("en-add-property-con").insertAdjacentHTML('beforeend', shtml)
}



function cen_show_add_prop() {
  let c_s = elements[current].element.styles
  let html = '<p class="en-prop-title">Styles</p>'
  for (const [i, v] of Object.entries(avail_styles)) {
    if (v in c_s == false) {
      html += "<div style='cursor:pointer;' onclick='cen_add_style(`" + v + "`)'>" + i + "</div>"
    }
  }
  document.getElementById("cen-add-property-con").innerHTML = html
  document.getElementById("cen-add-property").classList.toggle("toggle-flex")
}

function filt_clas(val) {
  let c_s = elements[current].element.styles
  let html = '<p class="en-prop-title">Styles</p>'
  for (const [i, v] of Object.entries(avail_styles)) {
    if (v in c_s == false) {
      if (val != "") {
        if (v.toLowerCase().includes(val.toLowerCase())) {
          html += "<div style='cursor:pointer;' onclick='cen_add_style(`" + v + "`)'>" + i + "</div>"

        }
      } else {

        html += "<div style='cursor:pointer;' onclick='cen_add_style(`" + v + "`)'>" + i + "</div>"
      }
    }
  }
  document.getElementById("cen-add-property-con").innerHTML = html

}

function aen_show_add_prop(k = null, l = false) {
  let c_s = animations[cur_anim].keyframes[k]
  let html = '<p class="en-prop-title">Styles</p>'
  for (const [i, v] of Object.entries(avail_styles)) {
    if (v in c_s == false) {
      html += "<div style='cursor:pointer;' onclick='aen_add_style(`" + k + "`,`" + v + "`)'>" + i + "</div>"
    }
  }
  document.getElementById("aen-add-property-con-" + k).innerHTML = html
  if (l) {
    load_key()
  }

  document.getElementById("aen-add-property-" + k).classList.toggle("toggle-flex")
}

function filt_anim(val, k, l = false) {
  let c_s = animations[cur_anim].keyframes[k]
  let html = '<p class="en-prop-title">Styles</p>'
  for (const [i, v] of Object.entries(avail_styles)) {
    if (v in c_s == false) {
      if (val != "") {
        if (v.toLowerCase().includes(val.toLowerCase())) {

          html += "<div style='cursor:pointer;' onclick='aen_add_style(`" + k + "`,`" + i + "`)'>" + v + "</div>"
        }
      } else {

        html += "<div style='cursor:pointer;' onclick='aen_add_style(`" + k + "`,`" + v + "`)'>" + i + "</div>"
      }
    }
  }
  document.getElementById("aen-add-property-con-" + k).innerHTML = html
  if (l) {
    load_key()
  }

}


function en_add_property(prop) {
  elements[current].element.properties[prop] = eval("new " + prop + "(current)")
  en_show_add_prop()
  elements[current].element.get_property()
}

function cen_add_property(prop) {
  classes[cclass].properties[prop] = eval("new " + prop + "(null)")
  cen_show_add_prop()
  classes[cclass].get_property()
}

function aen_add_style(k, prop) {
  animations[cur_anim].keyframes[k][prop] = eval("new " + prop + "(elemid='" + prop + "-en-anim-" + k + "')")
  aen_show_add_prop(k, true)
}

function en_add_style(prop) {
  elements[current].element.styles[prop] = eval("new " + prop + "(current)")
  en_show_add_prop()
  elements[current].element.get_property()
}

function cen_add_style(prop) {
  classes[cclass].styles[prop] = eval("new " + prop + "(null)")
  cen_show_add_prop()
  classes[cclass].get_property()
}

var copy_list = []
var copyid = ""

function copy_element(event) {
  copyid = menuid
  copy_list = structuredClone(elements[menuid].element.element_get_list())
  document.getElementById("en-menu").style.display = "none";
}

var pid = { "en-live-page": "en-live-page" }

function paste_element(event) {
  current = menuid
  for (const [i, k] of Object.entries(copy_list)) {
    add_new_html(i, k)
  }
}

function add_new_html(v, p) {
  let id = elements[v].element.id + "-copy" + "-" + uniqueId()
  while (elements[id] != null) {
    id = elements[v].element.id + "-copy" + "-" + uniqueId()

  }
  if (document.getElementById(id) == null) {
    if (pid[p] != "en-live-page" && pid[p] != null) {
      current = pid[p]
    }
    elements[id] = eval("new " + elements[v].constructor.name + "(id)")
    elements[id].element.classes = elements[v].element.classes
    for (const [h, c] of Object.entries(elements[v].properties)) {
      elements[id].properties[h] = eval("new " + h + "(id)")
      var va = c.property.value
      var ti = c.property.title
      elements[id].properties[h].property.value = va
      elements[id].properties[h].property.title = ti
    }
    for (const [h, c] of Object.entries(elements[v].styles)) {
      elements[id].styles[h] = eval("new " + h + "(id)")
      var va = c.style.value
      var ti = c.style.title
      elements[id].styles[h].style.value = va
      elements[id].styles[h].style.title = ti
      if (elements[id].styles[h].style.type == "multiple") {
        for (const [n, cl] of Object.entries(elements[v].styles[h].style.options)) {
          var val = cl.style.value
          var til = cl.style.title
          elements[id].styles[h].style.options[n].style.value = val
          elements[id].styles[h].style.options[n].style.title = til

        }
      }

    }
    elements[id].element.reload_element()

    elements[id].element.childof = current
    elements[id].element.Ename = elements[v].constructor.name

    elements[id].element.properties = elements[id].properties
    elements[id].element.styles = elements[id].styles
    if (current != "en-live-page") {
      elements[current].element.childs[Object.keys(elements[current].element.childs).length + 1] = id
    }

    pid[v] = id
    document.getElementById("en-menu").style.display = "none";
  }
}





//class tab

var classes = {}

var cclass = ""

var pageClasses = {}

class Class {
  constructor(name) {
    this.name = name
    this.properties = {}
    this.styles = {}
  }
  get_data() {

    let property_HTML = ``
    for (const [property, obj] of Object.entries(this.properties)) {
      property_HTML += obj.property.propertyHTML()
    }
    for (const [property, obj] of Object.entries(this.styles)) {
      property_HTML += obj.style.propertyHTML()
    }
    document.getElementById("en-l-tab-styles-p").innerHTML = ""
    document.getElementById("en-l-tab-styles-p").insertAdjacentHTML("beforeend", property_HTML)
  }

  get_property() {

    let property_HTML = ``
    for (const [property, obj] of Object.entries(this.properties)) {
      property_HTML += obj.property.propertyHTML()
    }
    for (const [property, obj] of Object.entries(this.styles)) {
      property_HTML += obj.style.propertyHTML()
    }
    document.getElementById("en-l-tab-styles-p").innerHTML = ""
    document.getElementById("en-l-tab-styles-p").insertAdjacentHTML("beforeend", property_HTML)
  }
}

function add_ceclass(data) {
  for (const [k, v] of Object.entries(data)) {

    classes[k] = new Class(v.name)
    let ns = {}
    let ds = v.styles
    for (const [a, b] of Object.entries(ds)) {
      ns[a] = eval("new " + b.style.nclass + "(null)")
      if (ns[a].style.options != null && ns[a].style.options["c1"] == null) {
        for (const [c, d] of Object.entries(ns[a].style.options)) {
          d.style.value = b.style.options[c].style.value
        }
      } else {
        ns[a].style.value = b.style.value
      }
    }
    classes[k].styles = ns
    classes[k].styles = ns
  }
  if (Object.keys(classes)[0] != null) {
    cclass = Object.keys(classes)[0]
    load_classes()
    load_class()
  }

}

function load_page_classes() {
  cclass = ""
  classes = {}
  for (const [k, v] of Object.entries(pageClasses)) {

    classes[k] = new Class(v.name)
    let ns = {}
    let ds = v.styles
    for (const [a, b] of Object.entries(ds)) {
      ns[a] = eval("new " + b.style.nclass + "(null)")
      if (ns[a].style.options != null && ns[a].style.options["c1"] == null) {
        for (const [c, d] of Object.entries(ns[a].style.options)) {
          d.style.value = b.style.options[c].style.value
        }
      } else {
        ns[a].style.value = b.style.value
      }
    }
    classes[k].styles = ns
    classes[k].styles = ns
  }
  if (Object.keys(classes)[0] != null) {
    cclass = Object.keys(classes)[0]
    load_classes()
    load_class()
  }
  load_page_anim()
}

function add_class() {
  let v = document.getElementById("en_c_name").value
  if (v != '') {
    classes[v] = new Class(v)
    load_classes()
    elements[current].element.get_class()
  }
}

function load_classes() {
  document.getElementById("en-l-tab-styles").innerHTML = ""
  for (const [a, b] of Object.entries(classes)) {
    document.getElementById("en-l-tab-styles").insertAdjacentHTML("beforeend", "<button onclick='load_class(`" + a + "`)'>" + a + "</button>")
  }
  if (cclass == "" && classes != {}) {
    cclass = Object.keys(classes)[0]
    load_class()
  }
}

function load_class(v = null) {
  if (v != null) {
    cclass = v
  }
  classes[cclass].get_data()
}




if (!location.pathname.includes("/download")) {
  elements[current].element.get_class()
}


//animation:

class animation {
  constructor(name) {
    this.name = name
    this.keyframes = {}
    this.duration = 1.0
  }
}

var animations = {},
  cur_anim = "",
  pageAnim = {}

function add_ceanim(data) {
  for (const [i, j] of Object.entries(data)) {

    animations[i] = new animation(j.name)
    for (const [k, v] of Object.entries(j.keyframes)) {
      let ns = null
      if (v != null) {
        for (const [a, b] of Object.entries(v)) {
          ns = eval("new " + b.style.nclass + "(null)")
          if (ns.style.type == "multiple") {
            for (const [c, d] of Object.entries(ns.style.options)) {
              d.style.value = b.style.options[c].style.value
            }
          } else {
            ns.style.value = b.style.value
          }
        }
        if (animations[i].keyframes[k] != null) {
          animations[i].keyframes[k].push(ns)
        } else {
          animations[i].keyframes[k] = [ns, ]

        }
      } else {
        animations[i].keyframes[k] = []

      }
    }
  }
  list_anims()
}

function load_page_anim() {
  cur_anim = ""
  animations = {}
  for (const [i, j] of Object.entries(pageAnim)) {

    animations[i] = new animation(j.name)
    for (const [k, v] of Object.entries(j.keyframes)) {
      let ns = null
      if (v != null) {
        for (const [a, b] of Object.entries(v)) {
          ns = eval("new " + b.style.nclass + "(null)")
          if (ns.style.type == "multiple") {
            for (const [c, d] of Object.entries(ns.style.options)) {
              d.style.value = b.style.options[c].style.value
            }
          } else {
            ns.style.value = b.style.value
          }
        }
        if (animations[i].keyframes[k] != null) {
          animations[i].keyframes[k].push(ns)
        } else {
          animations[i].keyframes[k] = [ns, ]

        }
      } else {
        animations[i].keyframes[k] = []

      }
    }
  }
  list_anims()

}

function list_anims() {
  let html = '',
    cv = ''
  if (cur_anim != '') {
    html = '<option vlaue="' + cur_anim + '">' + cur_anim + '</option>'
    cv = cur_anim
  } else {
    html = '<option value="">Select an Animation</option>'
    cv = ""
  }
  for (const [k, v] of Object.entries(animations)) {
    if (k != cur_anim) {
      html += '<option vlaue="' + k + '">' + k + '</option>'
    }
  }
  if (!location.pathname.includes("/download")) {
    document.getElementById("en-anim-l").innerHTML = `<select oninput="load_anim(this.value)" value="` + cv + `">` + html + `</select>`
  }
}

list_anims()

function add_anim() {
  let a_name = document.getElementById("en_a_name").value
  if (a_name != '' && animations[a_name] == null) {
    animations[a_name] = new animation(a_name)
    cur_anim = a_name
    list_anims()
    load_anim()
  }
}

function load_anim(v = null) {
  if (v != null) {
    cur_anim = v
  }
  document.getElementById("en-cur-a").innerText = cur_anim
  let html_main = '',
    html = '',
    keys = animations[cur_anim].keyframes
  for (const [k, v] of Object.entries(keys)) {
    html = ''
    for (const [s, c] of Object.entries(v)) {
      html += c.style.propertyHTML(null, null, true)
    }
    html_main += `
        <div class="en_anim-k">
        <div class="en-anim-time">
            <p>@ </p>
            <p>` + k + `</p>
            <p>s</p>
        </div>
        <div id="en-l-tab-anim-p-` + k + `" class="en-l-tab-anim-p">
        ` + html + `
        </div>
        
        <button class="en-btn" onclick="aen_show_add_prop('` + k + `')">Add Property</button>
        <div class="en-c-property" id="aen-add-property-` + k + `" >
            <input placeholder="Search Property" oninput="filt_anim(this.value,` + k + `)">
            <div class="en-custom-property" id="aen-add-property-con-` + k + `">

            </div>
        </div>

    </div>
        `
    document.getElementById("en_keyfs").innerHTML = html_main
  }
}

function add_key() {
  var t = document.getElementById("at-key").value
  if (t != "" && animations[cur_anim].keyframes[parseFloat(t)] == null) {
    let k = parseFloat(t)
    animations[cur_anim].keyframes[k] = {}
    load_anim()
  }
}

function set_dur(v) {
  animations[cur_anim].duration = parseFloat(v)
  document.getElementById("at-key").max = v.toString() + ".0";
}

function load_key() {
  let html = '',
    keys = animations[cur_anim].keyframes
  for (const [k, v] of Object.entries(keys)) {
    html = ''
    for (const [s, c] of Object.entries(v)) {
      html += c.style.propertyHTML(null, null, true)
    }
    document.getElementById("en-l-tab-anim-p-" + k).innerHTML = html
  }
}

function reload_css_anim() {
  let dur = animations[cur_anim].duration,
    keys = animations[cur_anim].keyframes,
    css = ""
  let css_main = '',
    css_sub = '',
    p = ''
  for (const [k, v] of Object.entries(keys)) {
    p = ((parseInt(k) / dur) * 100).toString()
    css_sub = ''
    for (const [i, c] of Object.entries(v)) {
      css_sub += c.style.get_css()
    }
    css_main += `
                ` + p + `%{
                ` + css_sub + `
                }
        `
  }
  css = `
    @keyframes ` + cur_anim + `{
        ` + css_main + `
    }`
  let st = document.getElementById(cur_anim)
  if (st != null) {
    st.innerHTML = css
  } else {
    document.body.insertAdjacentHTML("beforeend", "<style id='" + cur_anim + "'></style>")
    st = document.getElementById(cur_anim)
    st.innerHTML = css
  }
}

function load_css_anim_g(dur, keys, name) {
  let cur_anim = name
  let css = ""
  let css_main = '',
    css_sub = '',
    p = ''
  for (const [k, v] of Object.entries(keys)) {
    p = ((parseInt(k) / dur) * 100).toString()
    css_sub = ''
    for (const [i, c] of Object.entries(v)) {
      css_sub += c.style.get_css()
    }
    css_main += `
                ` + p + `%{
                ` + css_sub + `
                }
        `
  }
  css = `
    @keyframes ` + cur_anim + `{
        ` + css_main + `
    }`
  return css
}